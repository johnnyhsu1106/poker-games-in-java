import java.util.*;

public class DrawDealer extends Dealer{
	public DrawDealer(){
		super();

	}
	public DrawDealer(String name){
		super(name);

	}
    public void startHands(){
    	// THe implementation: Finish in the future
    }
}
